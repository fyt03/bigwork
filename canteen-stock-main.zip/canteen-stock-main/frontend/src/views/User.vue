<template>
    <div>
        这是用户组件
    </div>
</template>
<script>
export default {
    name: "User",
    data(){

    }
}

</script>