<template>
    <div style="overflow: hidden; height: 100vh">
      <img src="../assets/404.png" alt="404" style="width: 100%; height: 100vh">
    </div>
</template>

<script>
export default {
    name: "NotFound"
}
</script>

<style scoped>

</style>