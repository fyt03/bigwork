<template>
    <div>
        这是角色组件
    </div>
</template>
<script>
export default {
    name: "Role",
    data(){

    }
}

</script>